#!/bin/bash

list=`ls *.txt`
echo $list

