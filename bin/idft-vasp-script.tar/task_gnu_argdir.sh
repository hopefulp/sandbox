#!/bin/bash

file=shift $@

for dir in $@
    do
        cd $dir


  	cd ..
    done
